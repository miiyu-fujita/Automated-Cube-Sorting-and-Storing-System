#!/usr/bin/env python3

# TODO Add more details about your overall shoe retrieval system implementation in the docstring below
"""
Retrieve foam cubes given a certain color.
"""

# Adjust these imports based on your implementation
from logic import get_bin_for_color
from utils.brick import Color, configure_ports


# Initialize hardware devices here 


# Define your classes and functions here. Consider using other files if this one gets too large



if __name__ == "__main__":
    print("Starting shoe retrieval system...")
